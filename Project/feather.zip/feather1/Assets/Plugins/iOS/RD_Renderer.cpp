
#include "RD_Renderer.h"

RD_Renderer::RD_Renderer()
{
}

RD_Renderer::~RD_Renderer()
{
}
